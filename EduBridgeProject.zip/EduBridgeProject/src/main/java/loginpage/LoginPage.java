package loginpage;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import linkstesting.SignOnLink;

public class LoginPage {
	
	static WebDriver wb;
	XSSFWorkbook book;
	XSSFSheet sh1;
	XSSFSheet sh2;
	
	public static void login(int i , XSSFSheet sh)
	{
		String un = sh.getRow(i).getCell(0).toString();
		String pw = sh.getRow(i).getCell(1).toString();
		System.out.println(un + "     " + pw);
		
		wb.findElement(By.name("userName")).sendKeys(un);
		wb.findElement(By.name("password")).sendKeys(pw);
		wb.findElement(By.name("submit")).click();
	}

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		
		FileInputStream fis = new FileInputStream("C:\\Users\\DAKSHA\\Desktop\\ProjectSheet.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(fis);                    
		XSSFSheet sh1 = book.getSheet("signonV");
		XSSFSheet sh2 = book.getSheet("signonIN");
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
		wb = new ChromeDriver(); 
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		 
		System.out.println("No of records : " + sh1.getLastRowNum());
		  for(int i=1 ; i<=sh1.getLastRowNum() ; i++)
			{
			  LoginPage.login(i,sh1);
			  String t = wb.getTitle();
				if(t.contains("Login"))
				{
					System.out.println("Login Successfully");
					System.out.println("------------------------------------------------------");
					wb.findElement(By.linkText("SIGN-OFF")).click();
					//wb.findElement(By.linkText("SIGN-ON")).click();
				}
				else
				{
					System.out.println("Invalid Username/Password");
					//wb.findElement(By.linkText("SIGN-ON")).click();
				}
			}
		  
		  System.out.println("******************************************************");
			int size2 = sh2.getLastRowNum();
			System.out.println("No of records : " + size2);
			for(int i=1 ; i<=size2 ; i++)
				{
				LoginPage.login(i,sh2);
					String t = wb.getTitle();
					if(t.contains("Login"))
					{
						System.out.println("Test Case Failed.");
						System.out.println("------------------------------------------------------");
						wb.findElement(By.linkText("SIGN-OFF")).click();
						//wb.findElement(By.linkText("SIGN-ON")).click();
					}
					else
					{
						System.out.println("Test Case Passed.");
						wb.findElement(By.linkText("SIGN-OFF")).click();
					}
				}
		  wb.close();
		  wb.quit();
	}

}
