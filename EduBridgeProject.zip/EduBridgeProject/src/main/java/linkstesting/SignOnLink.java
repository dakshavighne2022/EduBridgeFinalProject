package linkstesting;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SignOnLink 
{
	static WebDriver wb;
	XSSFWorkbook book;
	XSSFSheet sh1;
	XSSFSheet sh2;
	

	public static void signon(int i , XSSFSheet sh)
	{
		String un = sh.getRow(i).getCell(0).toString();
		String pw = sh.getRow(i).getCell(1).toString();
		System.out.println(un + "     " + pw);
		
		wb.findElement(By.name("userName")).sendKeys(un);
		wb.findElement(By.name("password")).sendKeys(pw);
		wb.findElement(By.name("submit")).click();
	}

	public static void main(String[] args) throws IOException {
		
		FileInputStream fis = new FileInputStream("C:\\Users\\DAKSHA\\Desktop\\ProjectSheet.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(fis);                    
		XSSFSheet sh1 = book.getSheet("signonV");
		XSSFSheet sh2 = book.getSheet("signonIN");
		
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
	    wb = new ChromeDriver(); 
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		wb.findElement(By.linkText("SIGN-ON")).click();
		
		int size = sh1.getLastRowNum();
		System.out.println("No of records : " + size);
		for(int i=1 ; i<=size ; i++)
			{
				SignOnLink.signon(i,sh1);
				String t = wb.getTitle();
				if(t.contains("Login"))
				{
					System.out.println("Login Successfully");
					//System.out.println("Test Case Passed.");
					System.out.println("------------------------------------------------------");
					wb.findElement(By.linkText("SIGN-OFF")).click();
					wb.findElement(By.linkText("SIGN-ON")).click();
				}
				else
				{
					System.out.println("Invalid Username/Password");
					//System.out.println("Test Case Failed.");
					wb.findElement(By.linkText("SIGN-ON")).click();
				}
			}
		
		System.out.println("******************************************************");
		int size2 = sh2.getLastRowNum();
		System.out.println("No of records : " + size2);
		for(int i=1 ; i<=size2 ; i++)
			{
				SignOnLink.signon(i,sh2);
				String t = wb.getTitle();
				if(t.contains("Login"))
				{
					//System.out.println("Invalid Username/Password");
					System.out.println("Test Case Failed.");
					System.out.println("------------------------------------------------------");
					wb.findElement(By.linkText("SIGN-OFF")).click();
					wb.findElement(By.linkText("SIGN-ON")).click();
					wb.findElement(By.linkText("SIGN-ON")).click();
				}
				else
				{
					//System.out.println("Login Successfully");
					System.out.println("Test Case Passed.");
					wb.findElement(By.linkText("SIGN-OFF")).click();
				}
			}
		
		wb.close();
		wb.quit();

	}

}
