package linkstesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AllLinks {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
	    WebDriver wb = new ChromeDriver(); 
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		
		//-----------------------hotels------------------------------
		 WebElement hot = wb.findElement(By.linkText("Hotels"));
		  hot.click();
		  String t = wb.getTitle();
		  if(t.contains("Under Construction"))
		    {
			    System.out.println("Hotels");
		    	System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
		    	System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());
		    	System.out.println("------------------------------------------------");
		    }
		  wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]")).click();
		  
		//---------------------Car Rentals---------------------------------
		  wb.findElement(By.linkText("Car Rentals")).click();
		  String cr = wb.getTitle();
		  if(cr.contains("Under Construction"))
		    {
			    System.out.println("Car Rentals");
		    	System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
		    	System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());
		    	System.out.println("------------------------------------------------");
		    }		  
		  wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]")).click();
		  
		//----------------------Cruises-----------------------------------------
		  wb.findElement(By.linkText("Cruises")).click();
			String cru = wb.getTitle();
			if(cru.contains("Welcome") || wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
			{
				System.out.println("Crusies");
			    System.out.println("Page Not Found!!!");
			    System.out.println("------------------------------------------------");
		    }
			else
			{
				System.out.println("Page Found");
			}
			
		//---------------------------------Destinations----------------------------
			 wb.findElement(By.linkText("Destinations")).click();
			  String dest = wb.getTitle();
			  if(dest.contains("Under Construction"))
			    {
				    System.out.println("Destinations");
			    	System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
			    	System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());
			    	System.out.println("------------------------------------------------");
			    }
			  wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]")).click();
			  
		//--------------------------------Vacations------------------------------
			  wb.findElement(By.linkText("Vacations")).click();
			  String vac = wb.getTitle();
			  if(vac.contains("Under Construction"))
			    {
				    System.out.println("Vacations");
			    	System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
			    	System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());
			    }
			  wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]")).click();
		  
		wb.close();
		wb.quit();

	}

}
