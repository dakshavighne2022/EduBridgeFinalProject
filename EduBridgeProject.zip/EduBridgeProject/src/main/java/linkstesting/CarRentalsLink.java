package linkstesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CarRentalsLink {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
		  WebDriver wb = new ChromeDriver(); 
		  wb.manage().window().maximize();
		  wb.get("http://demo.guru99.com/test/newtours/");
		  
		  wb.findElement(By.linkText("Car Rentals")).click();
		  String t = wb.getTitle();
		  if(t.contains("Under Construction"))
		    {
		    	System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
		    	System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());
		    }
		  
		  wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]")).click();
		  
		  wb.close();
		  wb.quit();

	}

}
