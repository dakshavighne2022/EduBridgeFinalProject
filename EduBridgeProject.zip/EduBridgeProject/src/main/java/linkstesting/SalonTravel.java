package linkstesting;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SalonTravel {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
	    WebDriver  wb = new ChromeDriver(); 
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		
		JavascriptExecutor js = (JavascriptExecutor)wb;
		js.executeScript("window.scrollBy(0,5000)");
		Thread.sleep(3000);
		
		wb.findElement(By.linkText("Salon Travel")).click();
		String a = wb.getTitle();
		System.out.println(a);
		wb.navigate().back();
		wb.close();
		wb.quit();

	}

}
