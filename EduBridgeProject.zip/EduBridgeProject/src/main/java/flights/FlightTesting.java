package flights;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FlightTesting {

	public static void main(String[] args) throws IOException {

		FileInputStream fis = new FileInputStream("C:\\Users\\DAKSHA\\Desktop\\ProjectSheet.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(fis);                    
		XSSFSheet sh = book.getSheet("flightV");
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
		WebDriver wb = new ChromeDriver(); 
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		
		wb.findElement(By.linkText("Flights")).click();
		
		System.out.println("No of records : " + sh.getLastRowNum());
		for(int i=1 ; i<=sh.getLastRowNum() ; i++)
		{
			String type = sh.getRow(i).getCell(0).toString();
			String pass = sh.getRow(i).getCell(1).toString();
			String deptf = sh.getRow(i).getCell(2).toString();
			String onm = sh.getRow(i).getCell(3).toString();
			String ond = sh.getRow(i).getCell(4).toString();
			String arrive = sh.getRow(i).getCell(5).toString();
			String retm = sh.getRow(i).getCell(6).toString();
			String retd = sh.getRow(i).getCell(7).toString();
			String service = sh.getRow(i).getCell(8).toString();
			String air = sh.getRow(i).getCell(9).toString();
			
			System.out.println(type+"  "+pass+"  "+deptf+"  "+onm+"  "+ond+"  "+arrive+"  "+retm+"  "+retd+"  "+service+"  "+air);
			
			if(type.equalsIgnoreCase("round trip"))
			{
				wb.findElement(By.cssSelector("input[value='roundtrip']")).click();
			}
			else 
			{
				wb.findElement(By.cssSelector("input[value='oneway']")).click();
			}
			
			Select p = new Select(wb.findElement(By.name("passCount")));
			p.selectByVisibleText(pass);
			
			Select d = new Select(wb.findElement(By.name("fromPort")));
			d.selectByVisibleText(deptf);
			
			Select om = new Select(wb.findElement(By.name("fromMonth")));
			om.selectByVisibleText(onm);
			
			Select od = new Select(wb.findElement(By.name("fromDay")));
			od.selectByVisibleText(ond);
			
			Select ar = new Select(wb.findElement(By.name("toPort")));
			ar.selectByVisibleText(arrive);
			
			Select rm = new Select(wb.findElement(By.name("toMonth")));
			rm.selectByVisibleText(retm);
			
			Select rd = new Select(wb.findElement(By.name("toDay")));
			rd.selectByVisibleText(retd);
			
			if(service.equalsIgnoreCase("Economy Class"))
			{
				wb.findElement(By.cssSelector("input[value='Coach']")).click();
			}
			else if(service.equalsIgnoreCase("Business Class"))
			{
				wb.findElement(By.cssSelector("input[value='Business']")).click();
			}
			else
			{
				wb.findElement(By.cssSelector("input[value='First']")).click();
			}
			
			Select a = new Select(wb.findElement(By.name("airline")));
			a.selectByVisibleText(air);
			
			if(deptf.equals(arrive) || onm.equals(retm) && ond.equals(retd) || air.contains("No"))
			{
				System.out.println("Test Case Failed");
				System.out.println("-----------------------------------------------");
				wb.findElement(By.name("findFlights")).click();
				wb.findElement(By.xpath("//tbody/tr[2]/td[1]/a[1]/img[1]")).click();
				wb.findElement(By.linkText("Flights")).click();
			}
			else
			{
				System.out.println("Test Case Passed");
				System.out.println("-----------------------------------------------");
				wb.findElement(By.name("findFlights")).click();
				wb.findElement(By.xpath("//tbody/tr[2]/td[1]/a[1]/img[1]")).click();
				wb.findElement(By.linkText("Flights")).click();
			}

		}
		wb.close();
		wb.quit();

	}

}
