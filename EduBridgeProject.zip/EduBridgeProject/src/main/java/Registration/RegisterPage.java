package Registration;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RegisterPage {
	
	static WebDriver wb;
	XSSFWorkbook book;
	XSSFSheet sh1;
	XSSFSheet sh2;
	static String un;
	static String pw;
	
	public static void register(int i , XSSFSheet sh)
	{
		String fn = sh.getRow(i).getCell(0).toString();
		String ln = sh.getRow(i).getCell(1).toString();
		String phn = sh.getRow(i).getCell(2).toString();
		String em = sh.getRow(i).getCell(3).toString();
		String add = sh.getRow(i).getCell(4).toString();
		String ci = sh.getRow(i).getCell(5).toString();
		String st = sh.getRow(i).getCell(6).toString();
		String postc = sh.getRow(i).getCell(7).toString();
		String coun = sh.getRow(i).getCell(8).toString();
		un = sh.getRow(i).getCell(9).toString();
		pw = sh.getRow(i).getCell(10).toString();
		String cpw = sh.getRow(i).getCell(11).toString();
		
		System.out.println(fn+"  "+ln+"  "+phn+"  "+em+"  "+add+"  "+ci+"  "+st+"  "+postc+"  "+coun+"  "+un+"  "+pw+"  "+cpw );
		
		wb.findElement(By.name("firstName")).sendKeys(fn);
		wb.findElement(By.name("lastName")).sendKeys(ln);
		wb.findElement(By.name("phone")).sendKeys(phn);
		wb.findElement(By.name("userName")).sendKeys(em);
		wb.findElement(By.name("address1")).sendKeys(add);
		wb.findElement(By.name("city")).sendKeys(ci);
		wb.findElement(By.name("state")).sendKeys(st);
		wb.findElement(By.name("postalCode")).sendKeys(postc);
		
		Select con = new Select (wb.findElement(By.name("country")));
		con.selectByVisibleText(coun);
		
		wb.findElement(By.name("email")).sendKeys(un);
		wb.findElement(By.name("password")).sendKeys(pw);
		wb.findElement(By.name("confirmPassword")).sendKeys(cpw);
		wb.findElement(By.name("submit")).click();
		
		
	}

	public static void main(String[] args) throws IOException {
		
		FileInputStream fis = new FileInputStream("C:\\Users\\DAKSHA\\Desktop\\ProjectSheet.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(fis);  
		XSSFSheet sh1 = book.getSheet("registerV");
		XSSFSheet sh2 = book.getSheet("registerIN");
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
		wb = new ChromeDriver(); 
	    wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		wb.findElement(By.linkText("REGISTER")).click();
		
		int size = sh1.getLastRowNum();
		System.out.println("No of records : " + size);
		for(int i=1 ; i<=size ; i++)
		{
			RegisterPage.register(i, sh1);
			//String t = wb.getTitle();
			if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
			{
				System.out.println("Registered Successfully");
				wb.findElement(By.xpath("//a[contains(text(),'sign-in')]")).click();;
				wb.findElement(By.name("userName")).sendKeys(un);
				wb.findElement(By.name("password")).sendKeys(pw);
				wb.findElement(By.name("submit")).click();
				if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/login_sucess.php"))
				{
					System.out.println("Login Susccessfully");
					System.out.println("Thank you");
				}
				else
				{
					System.out.println("Check your username or password");
				}
				wb.findElement(By.linkText("REGISTER")).click();
			}
			else
			{
				System.out.println("Not Registered");
			}
		}
		
		int size2 = sh2.getLastRowNum();
		System.out.println("No of Records : " + size2);
		for(int i=1 ; i<=size2 ; i++)
		{
			RegisterPage.register(i, sh2);
			if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
			{
				System.out.println("Test Case Failed!");
				System.out.println("--------------------------------------------------");
				wb.findElement(By.linkText("REGISTER")).click();
			}
			else
			{
				System.out.println("--------------------------------------------------");
				System.out.println("Test Case Passed!");
				wb.findElement(By.linkText("REGISTER")).click();
			}
		}
		    wb.close();
			wb.quit();
			
		
	}

}
